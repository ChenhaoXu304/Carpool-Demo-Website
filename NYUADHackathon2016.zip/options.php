<div id="options">
  	<div id="cabpool">NYUAD CabPool</div>
  	<ul>
  		<li><a href="listTrips.php">Browse Trips</a></li>
  		<li><a href="index_final.php">Create a New Trip</a></li>
		<li><a href="my_requests.php">Manage My Trips</a></li>
  	</ul>
  	<div id="logout"><a href="login.php">Log out</a></div>
  	</div>