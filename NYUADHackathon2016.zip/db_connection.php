<?php define("SERVER",'localhost');
define("USER",'cx473');
define("PASS",'cx473');
define("DB",'cab_pooling');
$connection = new mysqli(SERVER, USER, PASS, DB);
?>
