<?php 
	include("functions.php");
	include("db_connection.php");
	display_requests(find_rides(5));
?>