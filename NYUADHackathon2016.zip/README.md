# NYUADHackathon2016
Team: "Induction on the Reals"<br />
Project: A cab-pooling app
